import 'package:flutter/material.dart';

class ListOfPizza extends StatelessWidget {
  const ListOfPizza({Key? key}) : super(key: key);

  ListView _printPizza() {
    return ListView.builder(
      
      itemBuilder: (BuildContext ctx, int index) {
      return ListTile(
        
        onTap: () {},
        leading: Image.network("https://www.simplyrecipes.com/thmb/8caxM88NgxZjz-T2aeRW3xjhzBg=/2000x1125/smart/filters:no_upscale()/__opt__aboutcom__coeus__resources__content_migration__simply_recipes__uploads__2019__09__easy-pepperoni-pizza-lead-3-8f256746d649404baa36a44d271329bc.jpg"
            //songs[index].image,
            ),
        title: const Text(
            // songs[index].trackName
            "Pizza"),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: double.maxFinite,
      width: double.maxFinite,
      child: _printPizza(),
    );
  }
}
