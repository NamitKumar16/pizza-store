import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pizza_store/modules/screens/list_of_pizza.dart';

class Dashboard extends StatelessWidget {
  const Dashboard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(
            'Order Details',
            style: TextStyle(
                color: Colors.indigo.shade900, fontWeight: FontWeight.w700),
          ),
          systemOverlayStyle: SystemUiOverlayStyle.dark, // 1

          backgroundColor: Colors.transparent,
          elevation: 0,
          actions: const [
            Padding(
              padding: EdgeInsets.fromLTRB(0, 0, 21, 0),
              child: Icon(
                Icons.info_outline,
                color: Colors.grey,
              ),
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(0, 0, 30, 0),
              child: Icon(
                Icons.menu,
                color: Colors.grey,
              ),
            )
          ]),
      body: Container(
        child: Column(
          children: [
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 40),
                  child: ElevatedButton(
                      onPressed: () {},
                      child: Row(
                        children: [
                          Text(
                            'My Cart',
                            
                            style: TextStyle(
                                color: Colors.indigo.shade900,
                                fontWeight: FontWeight.w700,
                                fontSize: 20),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Icon(Icons.shopping_basket_outlined,color: Colors.grey,),
                          )
                        ],
                      ),
                      style: ButtonStyle(
                        shape:
                            MaterialStateProperty.all<RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                   )),
                        backgroundColor:
                            MaterialStateProperty.all<Color>(Colors.white),
                      )),
                ),
                SizedBox(width: 60,),
                Container(
                  color: Color.fromARGB(255, 255, 225, 0),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('\$94 total',style: TextStyle(
                      color: Colors.white,
                      fontSize: 20
                    ),),
                  ),
                )
              ],
            ),
            Row(
              children: [
                ListOfPizza()
              ],
            )
            
          ],
        ),
      ),
    );
  }
}
