
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pizza_store/modules/screens/dashboard.dart';


void main(){
  
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Dashboard(),
  )
  );
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(

    statusBarColor: Color.fromARGB(255, 255, 225, 0),
    

  ));
}